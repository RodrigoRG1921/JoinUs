export { default } from './RestaurantCard'
