export { default } from './DetailView'
