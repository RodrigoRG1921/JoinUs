export { default } from './PreferencesView'
