type RootStackParamList = {
  SplashScreen: undefined;
  DrawerNavigator: undefined;

  RestaurantDetailScreen: undefined;
  SearchScreen: undefined;

  StepperScreen: undefined;
}

export type {
  RootStackParamList
}
