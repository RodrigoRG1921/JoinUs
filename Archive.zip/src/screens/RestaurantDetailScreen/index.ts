export { default } from './RestaurantDetailScreen'
